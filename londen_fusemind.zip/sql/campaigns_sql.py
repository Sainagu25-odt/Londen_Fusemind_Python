

GET_ACTIVE_CAMPAIGNS_SQL = """
SELECT * FROM campaigns
WHERE deleted_at IS NULL
  AND campaign_subquery_id IS NULL
"""

GET_DELETED_CAMPAIGNS_SQL = """
SELECT * FROM campaigns
WHERE deleted_at IS NOT NULL
  AND campaign_subquery_id IS NULL
"""


soft_delete_sql = """
    UPDATE campaigns
    SET deleted_at = NOW()
    WHERE id = :campaign_id
"""

undelete_sql = """
    UPDATE campaigns
    SET deleted_at = NULL
    WHERE id = :campaign_id
"""


GET_CAMPAIGN = """
SELECT 
    c.id,
    c.name,
    c.description,
    c.channel,
    c.begin_date,
    c.deleted_at IS NOT NULL AS deleted,
    d.tablename
FROM campaigns c
LEFT JOIN campaign_datasources d ON c.datasource = d.datasource
WHERE c.id = :id
"""

GET_CRITERIA = """
SELECT 
    cc.id AS row_id,
    cc.column_name,
    cc.sql_type AS operator,
    cc.sql_value AS value,
    cc.or_next AS is_or
FROM campaign_criteria cc
WHERE cc.campaign_id = :id
ORDER BY cc.position
"""

GET_SUBQUERY_CHILDREN = """
SELECT 
    c.id, 
    c.name, 
    c.begin_date,
    c.deleted_at IS NOT NULL AS deleted
FROM campaigns c
WHERE c.subquery = TRUE AND c.campaign_subquery_id = :parent_id
ORDER BY c.id
"""

GET_SUBQUERY_CRITERIA = """
SELECT 
    cc.id AS row_id,
    cc.column_name,
    cc.sql_type AS operator,
    cc.sql_value AS value,
    cc.or_next AS is_or
FROM campaign_criteria cc
WHERE cc.campaign_id = :sub_id
ORDER BY cc.position
"""

GET_SUBQUERY_JOIN = """
SELECT 
    cs.label,
    cs.parent_table,
    cs.child_table,
    cs.parent_field,
    cs.child_field
FROM campaign_subqueries cs
WHERE cs.campaign_id = :parent_id AND cs.subquery_campaign_id = :sub_id
"""

ADD_CRITERION = """
    INSERT INTO campaign_criteria 
        (campaign_id, column_name, sql_type, sql_value, or_next)
    VALUES 
        (:campaign_id, :column_name, :sql_type, :sql_value, :or_next)
"""


SAVE_CRITERIA_INSERT = """
INSERT INTO campaign_criteria (campaign_id, column_name, sql_type, sql_value, or_next)
VALUES (:campaign_id, :column_name, :operator, :value, :is_or)
"""

SAVE_CRITERIA_UPDATE = """
UPDATE campaign_criteria
SET column_name = :column_name,
    sql_type = :operator,
    sql_value = :value,
    or_next = :is_or
WHERE id = :id AND campaign_id = :campaign_id
"""

DELETE_CRITERIA_ROW = """
DELETE FROM campaign_criteria
WHERE id = :id AND campaign_id = :campaign_id
"""


ADD_CAMPAIGN = """
    INSERT INTO campaigns (name, description, channel, datasource, begin_date)
    VALUES (:name, :description, :channel, :datasource, :begin_date)
    RETURNING id
"""

GET_DROPDOWN_FOR_DATASOURCE = """
    SELECT datasource FROM campaign_datasources
"""

GET_USER_FROM_TOKEN = """
SELECT username, email
FROM users
WHERE token = :token
"""

GET_CAMPAIGN_DETAILS_BY_ID = """
SELECT id, name, channel FROM campaigns WHERE id = :campaign_id
"""


GET_PREBUILT_FIELDSETS_BY_CAMPAIGN = """
SELECT id, label FROM campaign_list_fieldsets
WHERE datasource = (
    SELECT datasource FROM campaigns WHERE id = :campaign_id
)
"""

GET_CAMPAIGN_COLUMNS_BY_ID = """
SELECT column_name FROM campaign_criteria WHERE campaign_id = :campaign_id
"""

# Previous pulls for this campaign
GET_PREVIOUS_PULLS_BY_CAMPAIGN = """
SELECT name, requested_at, requested_by, householding, every_n, num_records
FROM campaign_lists
WHERE campaign_id = :campaign_id
AND completed_at IS NOT NULL
ORDER BY requested_at DESC
"""



GET_ACTIVE_PULLS_BY_CAMPAIGN = """
SELECT cl.id AS list_id, c.name AS campaign, cl.name,
    cl.requested_by,
    cl.requested_at,
    cl.completed_at, cl.householding, cl.every_n, cl.num_records
FROM campaign_lists cl
JOIN campaigns c ON c.id = cl.campaign_id
AND cl.completed_at IS NULL
ORDER BY cl.requested_at DESC
"""

GET_LATEST_PULL_SETTINGS = """
SELECT every_n, num_records, fields, fieldset_id,
       excluded_pulls, householding, request_email
FROM campaign_lists
WHERE campaign_id = :campaign_id
ORDER BY requested_at DESC LIMIT 1
"""

INSERT_PULL_LIST = """
INSERT INTO campaign_lists (
    campaign_id, requested_at, completed_at,
    fieldset_id, every_n, num_records,
    fields, requested_by, excluded_pulls,
    householding, request_email, criteria_sql, name
) VALUES (
    :campaign_id, :requested_at, :completed_at,
    :fieldset_id, :every_n, :num_records,
    :fields, :requested_by, :excluded_pulls,
    :householding, :request_email, :criteria_sql, :name
)
"""

# sql/campaign_queries.py

GET_ALL_CAMPAIGNS_SQL = """
SELECT id AS campaign_id, name AS campaign, datasource
FROM campaigns
WHERE deleted_at IS NULL AND campaign_subquery_id IS NULL;
"""

GET_CAMPAIGN_DETAILS_SQL = """
SELECT id, name, datasource
FROM campaigns
WHERE id = :campaign_id
  AND deleted_at IS NULL
  AND campaign_subquery_id IS NULL;
"""





# queries/campaign_queries.py
GET_CAMPAIGN_TABLE = """
SELECT c.name, c.channel, ds.tablename
FROM campaigns c
JOIN campaign_datasources ds ON c.datasource = ds.datasource
WHERE c.id = :campaign_id
"""

GET_HOUSEHOLD_FIELDS = """
SELECT string_agg(column_name, ',') AS hf
FROM campaign_datasource_household
WHERE datasource = (
    SELECT datasource FROM campaigns WHERE id = :campaign_id
)
"""

SQL_COUNTS_BY_STATE = """
SELECT coalesce(sl.state_name, p.state) AS state, count(*) AS total
FROM {table_name} p
LEFT JOIN state_lookup sl ON p.state = sl.state_code
WHERE TRUE {exclude}
GROUP BY coalesce(sl.state_name, p.state)
ORDER BY state
"""

SQL_TOTAL_COUNTS = """
SELECT count(*) AS total
FROM {table_name} p
WHERE TRUE {exclude}
"""

SQL_HOUSEHOLD_COUNTS = """
SELECT count(*) AS total_households, sum(cnt) AS total_dups
FROM (
  SELECT {fields}, coalesce(sl.state_name, p.state) AS state_code, count(*) AS cnt
  FROM {table_name} p
  LEFT JOIN state_lookup sl ON p.state = sl.state_code
  WHERE TRUE {exclude}
  GROUP BY {fields}, coalesce(sl.state_name, p.state)
) AS s
"""

SQL_GLOBAL_CAMPAIGNS = """
SELECT c.id, ds.tablename
FROM campaigns c
JOIN campaign_datasources ds ON c.datasource = ds.datasource
WHERE c.deleted_at IS NULL AND c.campaign_subquery_id IS NULL
"""

GET_CAMPAIGN_LIST_FILENAME = """
SELECT name
FROM campaign_lists
WHERE id = :id
"""

get_campaign_records_sql = '''
SELECT {primary_key}, 
       coalesce(state_name, state_code) AS state_code,
       array_to_string (
           ARRAY(
               SELECT DISTINCT campaign_list_id 
               FROM campaign_list_data AS d 
               WHERE d.keyvalue = {pk_concat_sql}
           ), ','
       ) as lists
FROM {table_name} AS p
    {joins}
WHERE TRUE
    {where_conditions}
ORDER BY {order_by}
LIMIT {limit} OFFSET {offset}
'''


GET_ALL_CAMPAIGN = """
SELECT * FROM campaigns WHERE id = :id
"""

INSERT_INTO_CAMPAIGN = """
INSERT INTO campaigns (name, channel, datasource, subquery, campaign_subquery_id)
VALUES (:name, :channel, :datasource, :subquery, :campaign_subquery_id)
RETURNING id
"""

GET_ALL_CAMPAIGN_CRITERIA = """
SELECT * FROM campaign_criteria WHERE campaign_id = :id
"""

INSERT_CAMPAIGN_CRITERIA = """
INSERT INTO campaign_criteria (
campaign_id, column_name, sql_type, sql_value, position, or_next
) VALUES (
:campaign_id, :column_name, :sql_type, :sql_value, :position, :or_next
)
"""